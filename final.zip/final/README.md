1. 서비스 개요 및 모델 정보
본 서비스는 Flask 및 Gunicorn WSGI 서버를 기반으로 구축된 PDF 문서 번역 API입니다. 사용자가 HTTP POST 요청으로 PDF 파일을 업로드하면, 학습된 Sequence-to-Sequence 모델을 활용하여 문서 내용 일부를 한국어로 번역하고 그 결과를 JSON 형태로 반환합니다.

모델 파일의 용량이 매우 커서 압축 파일에 직접 포함하지 않았습니다. 서비스를 실행하기 전에 https://drive.google.com/drive/folders/1h7E7BVUraKPLw69ltUiSjvMssa8oU6Fw?usp=sharing 에서 모델 폴더를 다운로드해야 합니다.

2. 모델 경로 수정 안내
제출된 flask_app.py 파일에는 모델 경로가 **MODEL_PATH = '/content/drive/MyDrive/AIHUB_DATA/final_nmt_model_1500'**으로 설정되어 있습니다.

평가자께서는 다운로드한 모델 폴더를 적절한 위치에 배치한 후, flask_app.py 파일 내의 MODEL_PATH 변수를 실제 다운로드 위치에 맞게 반드시 수정해야 합니다.

3. 실행 환경 및 의존성 설치
서비스를 실행하기 위해 Python 3.x 환경이 필요하며, GPU 환경을 권장합니다. 제공된 requirements.txt 파일을 사용하여 필요한 모든 라이브러리를 설치해야 합니다.
pip install -r requirements.txt

4. 서비스 구동 방법 (Gunicorn + ngrok)
서비스 구동은 Gunicorn 서버와 ngrok 터널을 이용합니다.

ngrok 인증 토큰 설정: 먼저 ngrok 인증 토큰을 설정하십시오.

ngrok config add-authtoken <사용자 토큰>
Gunicorn 서버 구동: Gunicorn 서버를 5000번 포트에서 백그라운드(&)로 실행해야 합니다.

gunicorn --bind 0.0.0.0:5000 flask_app:app & 
ngrok 터널링 시작: 로컬 서버를 공용 인터넷 주소에 연결하십시오. 이 명령을 실행하면 서비스의 공용 주소(URL)가 출력됩니다.

ngrok http 5000
API 엔드포인트 확인: ngrok 실행 시 출력된 URL에 /translate_pdf를 붙인 주소가 최종 번역 요청 엔드포인트가 됩니다.
예: https://<ngrok_url>.ngrok-free.dev/translate_pdf

5. API 테스트 방법
테스트할 PDF 파일(sample.pdf)을 준비한 후, 아래 파이썬 스크립트를 실행하여 서비스를 이용하십시오. 요청 시 파일의 필드 이름은 **pdf_file**로 지정해야 합니다.

Python

import requests
import json

# 1. ngrok이 제공한 URL로 변경하십시오.
API_ENDPOINT = "https://<ngrok_url>.ngrok-free.dev/translate_pdf" 
TEST_FILE_PATH = "sample.pdf" 

try:
    with open(TEST_FILE_PATH, 'rb') as f:
        # 파일 필드명은 반드시 'pdf_file'이어야 합니다.
        files = {'pdf_file': (TEST_FILE_PATH, f, 'application/pdf')} 
        response = requests.post(API_ENDPOINT, files=files, timeout=60)
        response.raise_for_status() 
        print(json.dumps(response.json(), indent=4, ensure_ascii=False))
except Exception as e:
    print(f"API 요청 실패: {e}")